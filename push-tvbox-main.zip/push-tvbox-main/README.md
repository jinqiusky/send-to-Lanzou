# tvbox-build

[![Build](https://shields.io/github/workflow/status/celetor/tvbox-build/Build?logo=github&label=Build)](https://github.com/celetor/tvbox-build/actions)
[![Download](https://img.shields.io/github/v/release/celetor/tvbox-build?color=orange&logoColor=orange&label=Download&logo=DocuSign)](https://github.com/celetor/tvbox-build/releases/latest) 
[![Total](https://shields.io/github/downloads/celetor/tvbox-build/total?logo=Bookmeter&label=Counts&logoColor=blue&color=blue)](https://github.com/celetor/tvbox-build/releases)

+ Update Time: 2022/09/24 10:47
+ [lanzouCloud](https://wwi.lanzoup.com/b0dah3rlc)  Password: `celetor`

## Credits
This repo relies on the following third-party projects:
- [CatVodTVOfficial/TVBoxOSC](https://github.com/CatVodTVOfficial/TVBoxOSC)
- [q215613905/TVBoxOS](https://github.com/q215613905/TVBoxOS)
