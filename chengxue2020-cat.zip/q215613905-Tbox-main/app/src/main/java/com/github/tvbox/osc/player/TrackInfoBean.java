package com.github.tvbox.osc.player;

public class TrackInfoBean {
    public String name;
    public String language;
    public int index;
    public boolean selected;
}
